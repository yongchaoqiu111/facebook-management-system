<template>
  <div class="chat-container">
    <!-- 聊天头部 -->
    <ChatHeader 
      :contact="currentContact"
      :chain-group-info="chainGroupInfo"
      @back="goBack"
      @invite="showInviteModal = true"
      @share="shareGroup"
      @info="showInfoModal = true"
    />

    <!-- 接龙群状态条 -->
    <ChainStatusBar 
      v-if="chainGroupInfo"
      :chain-group-info="chainGroupInfo"
      :wait-countdown="chainWaitCountdown"
    />

    <!-- 消息列表 -->
    <MessageList
      :messages="messages"
      @open-red-packet="openRedPacket"
    />

    <!-- 输入框 -->
    <ChatInput
      v-model="messageInput"
      @send="sendMessage"
      @show-red-packet="showRedPacketModalVisible = true"
    />

    <!-- 邀请弹窗 -->
    <InviteModal 
      v-if="showInviteModal"
      :group-id="currentContact?.id"
      @close="showInviteModal = false"
    />
    
    <!-- 说明弹窗 -->
    <InfoModal
      v-if="showInfoModal"
      @close="showInfoModal = false"
    />
    
    <!-- 红包弹窗 -->
    <RedPacketModal
      v-if="showRedPacketModalVisible"
      @close="showRedPacketModalVisible = false"
      @send="handleSendRedPacket"
    />
    
    <!-- 抢红包结果弹窗 -->
    <div v-if="showRedPacketResultModal" class="modal-overlay" @click="showRedPacketResultModal = false">
      <div class="red-packet-result-modal" @click.stop>
        <div class="result-header">
          <div class="result-icon">🧧</div>
          <h3>恭喜抢到红包！</h3>
        </div>
        <div class="result-body">
          <div class="result-amount">
            <span class="amount-value">{{ redPacketResult.amount }}</span>
            <span class="amount-unit">USDT</span>
          </div>
          <div class="result-message">{{ redPacketResult.message }}</div>
          <div class="result-from">来自 {{ redPacketResult.from }}</div>
          <div v-if="redPacketResult.totalReceived" class="result-total">
            累计领取: {{ redPacketResult.totalReceived }} USDT
          </div>
        </div>
        <button class="result-close-btn" @click="showRedPacketResultModal = false">开心收下</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import ChatHeader from '@/components/ChatHeader.vue'
import ChainStatusBar from './components/ChainStatusBar.vue'
import MessageList from './components/MessageList.vue'
import ChatInput from './components/ChatInput.vue'
import InviteModal from './modals/InviteModal.vue'
import InfoModal from './modals/InfoModal.vue'
import RedPacketModal from './modals/RedPacketModal.vue'
import { useChainGroupChat } from './composables/useChainGroupChat'
import { getSocket } from '@/socket'

const route = useRoute()
const chatId = route.params.id

// 获取socket实例
const socket = getSocket()

// 红包相关状态
const chainProgress = ref({
  totalClaimed: 0,
  threshold: 380,
  entryFee: 310,
  remainToThreshold: 380,
  isExceeded: false,
  status: 'active',
  topClaimers: []
})

const redPacketBill = ref([])

// 使用 composable
const {
  currentContact,
  chainGroupInfo,
  messages,
  messageInput,
  showInviteModal,
  showInfoModal,
  showRedPacketModalVisible,
  showRedPacketResultModal,
  redPacketResult,
  chainWaitCountdown,
  goBack,
  shareGroup,
  openRedPacket,
  sendMessage,
  handleSendRedPacket,
  init,
  cleanup
} = useChainGroupChat(chatId)

// 更新接龙进度
function updateChainProgress(data) {
  chainProgress.value = {
    totalClaimed: data.totalClaimed,
    threshold: data.threshold,
    entryFee: data.entryFee,
    remainToThreshold: data.remainToThreshold,
    isExceeded: data.isExceeded,
    status: data.status,
    topClaimers: data.topClaimers || []
  }
  
  if (data.isExceeded) {
    alert(`⚠️ 累计领取 ${data.totalClaimed} USDT，已超过阈值 ${data.threshold} USDT！`)
  }
}

// 更新红包账单
function updateRedPacketBill(data) {
  const billItem = {
    id: `bill_${Date.now()}`,
    claimer: data.claimer,
    amount: data.amount,
    timestamp: data.timestamp
  }
  
  redPacketBill.value.unshift(billItem)
}

// 更新红包状态
function updateRedPacketStatus(data) {
  if (data.status === 'exceeded') {
    alert(`红包已达到阈值：${data.reason}`)
  } else if (data.status === 'finished') {
    alert('红包已领完')
  } else if (data.status === 'expired') {
    alert('红包已过期')
  }
}

// 显示我的抢红包结果
function showMyResult(data) {
  redPacketResult.value = {
    amount: data.amount,
    message: data.message,
    from: data.from,
    balance: data.balance,
    totalReceived: data.totalReceived || 0
  }
  
  showRedPacketResultModal.value = true
}

onMounted(() => {
  init()
  
  // 注册 WSS 监听器
  socket.on('chainRedPacketProgress', (data) => {
    console.log('📊 接龙进度更新:', data)
    updateChainProgress(data)
  })
  
  socket.on('redPacketClaimed', (data) => {
    console.log('💰 有人领取红包:', data)
    updateRedPacketBill(data)
  })
  
  socket.on('redPacketStatusUpdate', (data) => {
    console.log('🔄 红包状态变更:', data)
    updateRedPacketStatus(data)
  })
  
  socket.on('myRedPacketResult', (data) => {
    console.log('🎉 我抢到了红包:', data)
    showMyResult(data)
  })
})

onUnmounted(() => {
  // 移除监听器，防止内存泄漏
  socket.off('chainRedPacketProgress')
  socket.off('redPacketClaimed')
  socket.off('redPacketStatusUpdate')
  socket.off('myRedPacketResult')
  
  cleanup()
})
</script>

<style scoped>
.chat-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}
</style>

<style>
/* 全局样式 - 红包弹窗（不能scoped，因为是动态创建的DOM） */
.modal-overlay {
  position: fixed !important;
  top: 0 !important;
  left: 0 !important;
  width: 100% !important;
  height: 100% !important;
  background: rgba(0, 0, 0, 0.6) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  z-index: 9999 !important;
}

/* 红包账单弹窗 */
.red-packet-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
}

.red-packet-modal.show {
  opacity: 1;
  visibility: visible;
}

.red-packet-modal-content {
  width: 320px;
  background: linear-gradient(135deg, #ff4757 0%, #ff3742 100%);
  border-radius: 16px;
  padding: 40px 30px;
  text-align: center;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  transform: scale(0.8) translateY(20px);
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.red-packet-modal.show .red-packet-modal-content {
  transform: scale(1) translateY(0);
}

/* 红包封面样式 */
.red-packet-cover {
  text-align: center;
}

.red-packet-cover-header {
  margin-bottom: 30px;
}

.red-packet-icon {
  font-size: 48px;
  display: block;
  margin-bottom: 15px;
  animation: bounce 1s ease-in-out;
}

.red-packet-cover-title {
  font-size: 20px;
  font-weight: 600;
  color: white;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
  margin-bottom: 40px;
}

.red-packet-open-btn {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ffeb3b 0%, #fbc02d 100%);
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 36px;
  font-weight: 800;
  color: #d32f2f;
  margin: 0 auto;
  cursor: pointer;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  transition: all 0.3s ease;
  animation: pulse 2s infinite;
}

.red-packet-open-btn:hover {
  transform: scale(1.05);
  box-shadow: 0 12px 25px rgba(0, 0, 0, 0.4);
}

.red-packet-open-btn:active {
  transform: scale(0.95);
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-20px);
  }
  60% {
    transform: translateY(-10px);
  }
}

@keyframes pulse {
  0% {
    transform: scale(1);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  }
  50% {
    transform: scale(1.05);
    box-shadow: 0 12px 25px rgba(0, 0, 0, 0.4);
  }
  100% {
    transform: scale(1);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
  }
}

/* 抢红包结果弹窗 */
.red-packet-result-modal {
  text-align: center;
  max-width: 320px;
}

.result-header {
  padding: 24px 20px 16px;
}

.result-icon {
  font-size: 64px;
  margin-bottom: 12px;
  animation: bounce 1s ease infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}

.result-header h3 {
  margin: 0;
  color: #ff4d4f;
  font-size: 20px;
}

.result-body {
  padding: 0 20px 24px;
}

.result-amount {
  margin: 20px 0;
}

.amount-value {
  font-size: 48px;
  font-weight: bold;
  color: #ff4d4f;
  margin-right: 8px;
}

.amount-unit {
  font-size: 20px;
  color: #ff4d4f;
}

.result-message {
  font-size: 16px;
  color: #666;
  margin: 16px 0 8px;
}

.result-from {
  font-size: 14px;
  color: #999;
}

.result-total {
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px solid #e0e0e0;
  font-size: 15px;
  font-weight: 600;
  color: #ff4d4f;
}

.result-close-btn {
  width: calc(100% - 40px);
  margin: 0 20px 20px;
  padding: 12px;
  background: linear-gradient(135deg, #ff4d4f 0%, #cf1322 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s;
}

.result-close-btn:hover {
  background: linear-gradient(135deg, #ff7875 0%, #ff4d4f 100%);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 77, 79, 0.3);
}

/* 红包账单样式 */
.red-packet-bill {
  width: 100%;
  max-width: 400px;
}

.red-packet-bill-header {
  text-align: center;
  margin-bottom: 20px;
}

.red-packet-bill-info {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
}

.red-packet-bill-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.red-packet-bill-item:last-child {
  margin-bottom: 0;
}

.red-packet-bill-list {
  background: rgba(255, 255, 255, 0.1);
  border-radius: 10px;
  padding: 20px;
}

.red-packet-bill-list-title {
  font-size: 16px;
  font-weight: 600;
  color: white;
  margin-bottom: 15px;
  text-align: center;
}

.red-packet-bill-summary {
  text-align: center;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
  margin: 15px 0;
  padding: 10px;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 8px;
}

.red-packet-bill-list-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  font-size: 14px;
}

.red-packet-bill-list-item:last-child {
  border-bottom: none;
}

.red-packet-bill-user-info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.red-packet-bill-user {
  color: rgba(255, 255, 255, 0.9);
  font-weight: 500;
  margin-bottom: 4px;
}

.red-packet-bill-time {
  color: rgba(255, 255, 255, 0.6);
  font-size: 12px;
}

.red-packet-bill-amount {
  color: #ffeb3b;
  font-weight: 700;
  font-size: 16px;
}
</style>