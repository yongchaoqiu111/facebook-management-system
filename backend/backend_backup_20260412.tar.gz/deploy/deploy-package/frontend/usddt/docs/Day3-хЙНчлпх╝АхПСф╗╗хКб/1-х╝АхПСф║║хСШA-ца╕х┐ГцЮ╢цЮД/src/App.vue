<script setup>
import ChainGroupChat from './views/ChainGroupChat/index.vue'
</script>

<template>
  <ChainGroupChat />
</template>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  background-color: #f5f5f5;
}
</style>
